"""Повноцінний конектор для Tabletki.ua: REST API, PWA, Telegram-бот і MCP."""
