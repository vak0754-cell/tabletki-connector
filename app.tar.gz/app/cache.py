from __future__ import annotations

import asyncio
import json
import os
import random
import sqlite3
import time
from typing import Any, Optional


class SQLiteTTLCache:
    """Персистентний TTL-кеш на SQLite із WAL-режимом та неблокуючими async-обгортками."""

    CLEANUP_EVERY_N_WRITES = 50

    def __init__(self, db_path: str, default_ttl: int = 1200) -> None:
        self.db_path = db_path
        self.default_ttl = default_ttl
        self._write_count = 0
        parent = os.path.dirname(db_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS cache (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    expires_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_cache_expires_at ON cache (expires_at)"
            )
            conn.commit()

    def get(self, key: str) -> Optional[Any]:
        now = time.time()
        with self._connect() as conn:
            row = conn.execute(
                "SELECT value, expires_at FROM cache WHERE key = ?", (key,)
            ).fetchone()
            if not row:
                return None
            raw_value, expires_at = row
            if expires_at < now:
                conn.execute("DELETE FROM cache WHERE key = ?", (key,))
                conn.commit()
                return None
            return json.loads(raw_value)

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        effective_ttl = self.default_ttl if ttl is None else ttl
        if effective_ttl <= 0:
            return
        now = time.time()
        expires_at = now + effective_ttl
        payload = json.dumps(value, ensure_ascii=False, default=str)
        self._write_count += 1
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO cache (key, value, expires_at)
                VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value, expires_at=excluded.expires_at
                """,
                (key, payload, expires_at),
            )
            if self._write_count >= self.CLEANUP_EVERY_N_WRITES:
                conn.execute("DELETE FROM cache WHERE expires_at < ?", (now,))
                self._write_count = 0
            conn.commit()

    def clear_expired(self) -> int:
        now = time.time()
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM cache WHERE expires_at < ?", (now,))
            conn.commit()
            return cur.rowcount

    async def aget(self, key: str) -> Optional[Any]:
        return await asyncio.to_thread(self.get, key)

    async def aset(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        await asyncio.to_thread(self.set, key, value, ttl)

    async def aclear_expired(self) -> int:
        return await asyncio.to_thread(self.clear_expired)


class AsyncRateLimiter:
    """Асинхронний обмежувач частоти запитів із випадковою затримкою."""

    def __init__(self, rps: float = 1.0, min_jitter: float = 0.25, max_jitter: float = 0.85) -> None:
        self.min_interval = 1.0 / max(rps, 0.1)
        self.min_jitter = min_jitter
        self.max_jitter = max_jitter
        self._lock = asyncio.Lock()
        self._last_ts = 0.0

    async def acquire(self) -> None:
        async with self._lock:
            now = time.monotonic()
            wait = self.min_interval - (now - self._last_ts)
            jitter = random.uniform(self.min_jitter, self.max_jitter)
            delay = max(0.0, wait) + jitter
            if delay > 0:
                await asyncio.sleep(delay)
            self._last_ts = time.monotonic()