from __future__ import annotations

import asyncio
import json
import os
import random
import sqlite3
import time
from typing import Any, Optional


class SQLiteTTLCache:
    """Персистентний TTL-кеш на SQLite."""

    def __init__(self, db_path: str, default_ttl: int = 1200) -> None:
        self.db_path = db_path
        self.default_ttl = default_ttl
        parent = os.path.dirname(db_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.db_path, timeout=10)

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS cache (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    expires_at REAL NOT NULL
                )
                """
            )
            conn.commit()

    def get(self, key: str) -> Optional[Any]:
        now = time.time()
        with self._connect() as conn:
            row = conn.execute(
                "SELECT value, expires_at FROM cache WHERE key = ?", (key,)
            ).fetchone()
            if not row:
                return None
            raw_value, expires_at = row
            if expires_at < now:
                conn.execute("DELETE FROM cache WHERE key = ?", (key,))
                conn.commit()
                return None
            return json.loads(raw_value)

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        expires_at = time.time() + (ttl if ttl is not None else self.default_ttl)
        payload = json.dumps(value, ensure_ascii=False, default=str)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO cache (key, value, expires_at)
                VALUES (?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value, expires_at=excluded.expires_at
                """,
                (key, payload, expires_at),
            )
            conn.commit()

    def clear_expired(self) -> int:
        now = time.time()
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM cache WHERE expires_at < ?", (now,))
            conn.commit()
            return cur.rowcount


class AsyncRateLimiter:
    """Асинхронний обмежувач частоти запитів із випадковою затримкою."""

    def __init__(self, rps: float = 1.0, min_jitter: float = 0.25, max_jitter: float = 0.85) -> None:
        self.min_interval = 1.0 / max(rps, 0.1)
        self.min_jitter = min_jitter
        self.max_jitter = max_jitter
        self._lock = asyncio.Lock()
        self._last_ts = 0.0

    async def acquire(self) -> None:
        async with self._lock:
            now = time.monotonic()
            wait = self.min_interval - (now - self._last_ts)
            jitter = random.uniform(self.min_jitter, self.max_jitter)
            delay = max(0.0, wait) + jitter
            if delay > 0:
                await asyncio.sleep(delay)
            self._last_ts = time.monotonic()
