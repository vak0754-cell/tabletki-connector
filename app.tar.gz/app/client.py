from __future__ import annotations

import logging
import os
import re
from typing import Any, Optional
from urllib.parse import quote, unquote, urljoin

import httpx
from bs4 import BeautifulSoup

from app.cache import AsyncRateLimiter, SQLiteTTLCache
from app.config import settings
from app.models import (
    AnalogueItem,
    AnaloguesResponse,
    MedicineSearchItem,
    OffersResponse,
    PharmacyOffer,
    SearchResponse,
)

logger = logging.getLogger("tabletki.connector")

# Strip pack counts and dosages (e.g. "№10", "250 мг", "100 мл") before extracting prices.
NON_PRICE_TOKEN_RE = re.compile(
    r"(?:№\s*\d+|\b\d+(?:[.,]\d+)?\s*(?:мг|мкг|мл|г|шт|таб|капс|амп|фл|саше|доз|см|мм)\b\.?)",
    re.IGNORECASE,
)
_NUM = r"(\d{1,3}(?:[\s\xa0]\d{3})+|\d+)(?:[.,](\d{1,2}))?"

# 1. Explicit price range with currency ("121–352 грн", "від 121 - 352 ₴") -> captures lower bound.
PRICE_RANGE_RE = re.compile(
    rf"(?:від|от)?\s*{_NUM}\s*[-–—]\s*(?:\d{{1,3}}(?:[\s\xa0]\d{{3}})+|\d+)(?:[.,]\d{{1,2}})?\s*(?:грн\.?|₴|uah)",
    re.IGNORECASE,
)
# 2. Explicit currency after number ("від 352 грн", "352,00 грн", "352 ₴", "1 250.00 UAH").
PRICE_SUFFIX_RE = re.compile(
    rf"{_NUM}\s*(?:грн\.?|₴|uah)",
    re.IGNORECASE,
)
# 3. Explicit currency before number ("₴352", "₴ 352,00", "UAH 352").
PRICE_PREFIX_RE = re.compile(
    rf"(?:₴|uah)\s*{_NUM}",
    re.IGNORECASE,
)
# 4. Labeled price even if Google truncates "грн" ("Ціна: 352", "Ціна від 121...").
PRICE_LABELED_RE = re.compile(
    rf"(?:ціна|цена|вартість|price)(?:\s+(?:від|от))?\s*:?\s*{_NUM}"
    r"(?!\s*(?:мг|мкг|мл|г\b|шт|таб|капс|амп|фл|%|рок|міс|дн))",
    re.IGNORECASE,
)
# 5. "від 352..." truncated at end of snippet without "грн" (excludes "від 6 років").
PRICE_FROM_TRUNCATED_RE = re.compile(
    rf"\b(?:від|от)\s+{_NUM}(?=\s*(?:\.{{2,}}|$))",
    re.IGNORECASE,
)
# 6. Bare number fallback — used ONLY for dedicated price fields/HTML elements.
PRICE_BARE_RE = re.compile(_NUM)

PHARMACY_PATH_CITY_RE = re.compile(r"/pharmacy/([^/]+)/?", re.IGNORECASE)
ADDRESS_RE = re.compile(
    r"((?:вул\.|просп\.|пр-т\.?|бульв\.|б-р\.?|пл\.|пров\.)\s*[^,.;|\n]{3,60}(?:,\s*\d+[а-яА-Яa-zA-Z0-9/-]*)?)",
    re.IGNORECASE,
)

# Free Serper plans reject num > 10 ("Query pattern not allowed for free accounts").
SERPER_MAX_NUM = 10
# Street numbers and pack counts are often parsed as fake prices (e.g. 1 грн).
MIN_PLAUSIBLE_PRICE_UAH = 5.0

SERPER_KEY_MISSING_MSG = (
    "TABLETKI_SERPER_API_KEY is not set. "
    "On Render, add this secret in the service Environment settings. "
    "Without it the connector falls back to direct tabletki.ua requests, which Cloudflare WAF blocks. "
    "Create a key at https://serper.dev and set TABLETKI_SERPER_API_KEY."
)

SERPER_OFFERS_NOTE = (
    "Дані отримано з пошукового індексу Google (Serper), а не з live-залишків аптек. "
    "Перевірте актуальну наявність і ціну за посиланням бронювання."
)

SERPER_NEARBY_NOTE = (
    "У точному місті пропозицій в індексі Google не знайдено — показано найближчі міста/область "
    "(is_nearby=true). Перевірте наявність за посиланням бронювання."
)

EXCLUDED_SLUGS = frozenset(
    {
        "category",
        "categories",
        "pharmacy",
        "search",
        "faq",
        "connect",
        "uk",
        "ru",
        "news",
        "articles",
        "about",
        "contacts",
        "reviews",
        "info",
        "help",
        "blog",
        "manufacturer",
        "brand",
        "brands",
    }
)

CITY_UA: dict[str, str] = {
    "kyiv": "Київ",
    "kiev": "Київ",
    "lviv": "Львів",
    "odesa": "Одеса",
    "odessa": "Одеса",
    "dnipro": "Дніпро",
    "kharkiv": "Харків",
    "vinnytsia": "Вінниця",
    "zaporizhzhia": "Запоріжжя",
    "poltava": "Полтава",
    "chernihiv": "Чернігів",
    "cherkasy": "Черкаси",
    "zhytomyr": "Житомир",
    "sumy": "Суми",
    "rivne": "Рівне",
    "lutsk": "Луцьк",
    "ternopil": "Тернопіль",
    "ivano-frankivsk": "Івано-Франківськ",
    "uzhhorod": "Ужгород",
    "chernivtsi": "Чернівці",
    "khmelnytskyi": "Хмельницький",
    "kropyvnytskyi": "Кропивницький",
    "mykolaiv": "Миколаїв",
    "kherson": "Херсон",
    "kryvyi-rih": "Кривий Ріг",
    "bila-tserkva": "Біла Церква",
    "brovary": "Бровари",
    "irpin": "Ірпінь",
    "bucha": "Буча",
    "nizhyn": "Ніжин",
    "pryluky": "Прилуки",
    "bobrovytsia": "Бобровиця",
    "nosivka": "Носівка",
    "nosovka": "Носівка",
}

CITY_OBLAST: dict[str, str] = {
    "київ": "Київська область",
    "бровари": "Київська область",
    "ірпінь": "Київська область",
    "буча": "Київська область",
    "біла церква": "Київська область",
    "чернігів": "Чернігівська область",
    "ніжин": "Чернігівська область",
    "прилуки": "Чернігівська область",
    "носівка": "Чернігівська область",
    "бобровиця": "Чернігівська область",
    "львів": "Львівська область",
    "одеса": "Одеська область",
    "дніпро": "Дніпропетровська область",
    "кривий ріг": "Дніпропетровська область",
    "харків": "Харківська область",
    "вінниця": "Вінницька область",
    "запоріжжя": "Запорізька область",
    "полтава": "Полтавська область",
    "черкаси": "Черкаська область",
    "житомир": "Житомирська область",
    "суми": "Сумська область",
    "рівне": "Рівненська область",
    "луцьк": "Волинська область",
    "тернопіль": "Тернопільська область",
    "івано-франківськ": "Івано-Франківська область",
    "ужгород": "Закарпатська область",
    "чернівці": "Чернівецька область",
    "хмельницький": "Хмельницька область",
    "кропивницький": "Кіровоградська область",
    "миколаїв": "Миколаївська область",
    "херсон": "Херсонська область",
}


def clamp_serper_num(num: int) -> int:
    """Clamp Serper `num` to 1..10 so free-plan requests are accepted."""
    return max(1, min(int(num), SERPER_MAX_NUM))


def _resolve_serper_key(explicit_key: Optional[str] = None) -> Optional[str]:
    if explicit_key is not None:
        return explicit_key.strip() or None
    env_key = os.getenv("TABLETKI_SERPER_API_KEY")
    if env_key is not None:
        return env_key.strip() or None
    if settings.serper_api_key:
        return settings.serper_api_key.strip() or None
    return None


def missing_serper_key_message() -> Optional[str]:
    if _resolve_serper_key():
        return None
    return SERPER_KEY_MISSING_MSG


def _parse_match_float(match: re.Match[str]) -> Optional[float]:
    integer_part = re.sub(r"[\s\xa0]+", "", match.group(1))
    decimal_part = match.group(2)
    number_str = f"{integer_part}.{decimal_part}" if decimal_part else integer_part
    try:
        return float(number_str)
    except ValueError:
        return None


def extract_price(
    text: str,
    *,
    allow_bare_number: bool = False,
    min_price: float = 0.0,
) -> Optional[float]:
    """Extract a price in UAH from text.

    Supports ranges ("121–352 грн"), currency suffixes ("від 352 грн", "352,00 грн",
    "352 ₴"), currency prefixes ("₴352"), and labeled prices ("Ціна: 352").
    For unstructured Google/Serper snippets keep `allow_bare_number=False` so
    dosages ("250 мг"), pack sizes ("№30"), and pharmacy numbers ("Аптека 911")
    are never misread as prices.
    """
    if not text:
        return None
    cleaned = NON_PRICE_TOKEN_RE.sub(" ", text)
    patterns = [
        PRICE_RANGE_RE,
        PRICE_SUFFIX_RE,
        PRICE_PREFIX_RE,
        PRICE_LABELED_RE,
        PRICE_FROM_TRUNCATED_RE,
    ]
    if allow_bare_number:
        patterns.append(PRICE_BARE_RE)

    for pattern in patterns:
        for match in pattern.finditer(cleaned):
            val = _parse_match_float(match)
            if val is not None and val >= min_price:
                return val
    return None


def extract_price_from_serper_row(row: dict[str, Any]) -> Optional[float]:
    """Extract a plausible UAH price from Serper rich fields, attributes, title, and snippet."""
    for key in ("price", "priceRange"):
        raw = row.get(key)
        if raw is not None:
            val = extract_price(str(raw), allow_bare_number=True, min_price=MIN_PLAUSIBLE_PRICE_UAH)
            if val is not None:
                return val

    attributes = row.get("attributes")
    if isinstance(attributes, dict):
        for attr_key, attr_val in attributes.items():
            key_lower = str(attr_key).lower()
            is_price_attr = any(tok in key_lower for tok in ("цін", "цен", "варт", "price"))
            val = extract_price(
                str(attr_val),
                allow_bare_number=is_price_attr,
                min_price=MIN_PLAUSIBLE_PRICE_UAH,
            )
            if val is not None:
                return val

    text = f"{row.get('title', '')} {row.get('snippet', '')}"
    return extract_price(text, allow_bare_number=False, min_price=MIN_PLAUSIBLE_PRICE_UAH)


def extract_slug(href: str) -> str:
    clean = unquote(href).split("?")[0].split("#")[0]
    for prefix in (
        "https://tabletki.ua",
        "http://tabletki.ua",
        "https://www.tabletki.ua",
        "http://www.tabletki.ua",
    ):
        if clean.startswith(prefix):
            clean = clean[len(prefix):]
            break
    parts = [p for p in clean.strip("/").split("/") if p]
    if len(parts) >= 2 and parts[0] in ("uk", "ru"):
        return parts[1]
    return parts[0] if parts else clean


# "Compeed: інструкція + ціна від 121 грн" / "Compeed Мікс: ціна в аптеках Києва"
_TITLE_PRODUCT_RE = re.compile(
    r"^(?P<name>[^|:]+?)(?:\s*:\s*(?:інструкція|цена|ціна|инструкция))",
    re.IGNORECASE,
)
_PLACE_ID_RE = re.compile(r"^ChIJ[A-Za-z0-9_-]+$")


def _canonical_product_url(slug: str) -> str:
    return urljoin(settings.base_url, f"/uk/{quote(slug)}/")


def _title_product_name(title: str) -> Optional[str]:
    raw = (title or "").split("|")[0].strip()
    match = _TITLE_PRODUCT_RE.match(raw)
    if match:
        name = match.group("name").strip()
        if not name or "," in name or len(name) > 40:
            return None
        lowered = name.lower()
        if lowered.startswith(("пластир ", "набір ", "набор ", "категорія ")):
            return None
        return name
    return None


def _serper_row_link(row: dict[str, Any]) -> Optional[str]:
    """Return a tabletki.ua URL, synthesizing one when Serper only gives a Google redirect."""
    link = row.get("link") or ""
    if "tabletki.ua" in link:
        return link
    name = _title_product_name(row.get("title") or "")
    if not name:
        return None
    slug = name.replace(" ", "-").strip("-")
    if not slug or slug.lower() in EXCLUDED_SLUGS:
        return None
    return _canonical_product_url(slug)


def _normalize_query_term(slug: str) -> str:
    return unquote(slug).replace("-", " ").replace("_", " ").strip()


def _format_city_name(raw_city: str) -> str:
    decoded = unquote(raw_city).replace("-", " ").strip()
    mapped = CITY_UA.get(decoded.lower())
    return mapped or decoded


def _resolve_city_ua(city: str) -> str:
    lookup = city.strip().lower() if city.isascii() else city.strip()
    return CITY_UA.get(lookup, city.strip())


def _resolve_oblast(city: str, city_ua: str) -> Optional[str]:
    return CITY_OBLAST.get(city_ua.strip().lower()) or CITY_OBLAST.get(city.strip().lower())


def _city_matches(url_city: str, target_slug: str, target_ua: str) -> bool:
    u = unquote(url_city).replace("-", " ").strip().lower()
    t_slug = target_slug.replace("-", " ").strip().lower()
    t_ua = target_ua.replace("-", " ").strip().lower()
    if u in (t_slug, t_ua):
        return True
    if CITY_UA.get(u, "").lower() == t_ua:
        return True
    # Match Ukrainian inflected stem (e.g. "Носівка" / "Носівки" / "Носівці")
    if len(t_ua) >= 4 and u.startswith(t_ua[:-1]):
        return True
    return False


def _extract_address(text: str) -> Optional[str]:
    match = ADDRESS_RE.search(text or "")
    return match.group(1).strip(" ,.;") if match else None


def _extract_availability(text: str, attributes: Any = None) -> str:
    if isinstance(attributes, dict):
        for k, v in attributes.items():
            if any(tok in str(k).lower() for tok in ("наявн", "avail", "stock")):
                return str(v).strip()
    lower = (text or "").lower()
    if "немає в наявності" in lower or "відсутній" in lower:
        return "Немає в наявності"
    if "є в наявності" in lower or "в наявності" in lower:
        return "Є в наявності"
    return "Уточнюйте на сайті"


def _is_canonical_product_url(link: str) -> bool:
    lower = unquote(link).lower()
    return "/pharmacy/" not in lower and "/analogues/" not in lower


class TabletkiConnector:
    """Гібридний конектор: Serper Search API (для Render) + прямий httpx/Playwright (локально)."""

    def __init__(self, cache_db_path: Optional[str] = None, serper_api_key: Optional[str] = None) -> None:
        self.selectors = settings.load_selectors()
        self.serper_api_key = _resolve_serper_key(serper_api_key)
        self.cache = SQLiteTTLCache(
            cache_db_path or settings.cache_db_path,
            settings.cache_ttl_seconds,
        )
        self.limiter = AsyncRateLimiter(
            rps=settings.rate_limit_rps,
            min_jitter=settings.min_jitter_sec,
            max_jitter=settings.max_jitter_sec,
        )
        self._http = httpx.AsyncClient(
            http2=True,
            follow_redirects=True,
            timeout=settings.request_timeout_sec,
            headers={
                "User-Agent": settings.user_agent,
                "Accept-Language": "uk-UA,uk;q=0.9,en;q=0.8",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
        )

    async def close(self) -> None:
        await self._http.aclose()

    async def _serper_search(self, query: str, num: int = 10) -> dict[str, Any]:
        if not self.serper_api_key:
            raise RuntimeError(SERPER_KEY_MISSING_MSG)
        await self.limiter.acquire()
        resp = await self._http.post(
            "https://google.serper.dev/search",
            headers={"X-API-KEY": self.serper_api_key, "Content-Type": "application/json"},
            json={"q": query, "gl": "ua", "hl": "uk", "num": clamp_serper_num(num)},
        )
        resp.raise_for_status()
        return resp.json()

    def _collect_serper_search_rows(
        self,
        payload: dict[str, Any],
        by_slug: dict[str, MedicineSearchItem],
    ) -> None:
        candidates: list[dict[str, Any]] = []
        for row in payload.get("organic", []):
            candidates.append(row)
            for sl in row.get("sitelinks") or []:
                if isinstance(sl, dict) and sl.get("link"):
                    candidates.append(sl)

        for row in candidates:
            link = _serper_row_link(row)
            if not link:
                continue
            slug = extract_slug(link)
            if not slug or slug.lower() in EXCLUDED_SLUGS:
                continue

            slug_key = slug.lower()
            title = (row.get("title") or slug).split(":")[0].split("|")[0].strip()
            price = extract_price_from_serper_row(row)
            full_url = link if link.startswith("http") else urljoin(settings.base_url, link)
            # Search should point at the product page, not a city pharmacy/Place-ID URL.
            if "/pharmacy/" in unquote(full_url).lower() or "/analogues/" in unquote(full_url).lower():
                full_url = _canonical_product_url(slug)

            existing = by_slug.get(slug_key)
            if existing is None:
                by_slug[slug_key] = MedicineSearchItem(
                    name=title,
                    slug=slug,
                    url=full_url,
                    min_price_uah=price,
                )
            else:
                if price is not None and (
                    existing.min_price_uah is None or price < existing.min_price_uah
                ):
                    existing.min_price_uah = price
                if _is_canonical_product_url(full_url) and not _is_canonical_product_url(existing.url):
                    existing.url = full_url
                    if title:
                        existing.name = title

    def parse_serper_search(self, payload: dict[str, Any], limit: int = 10) -> list[MedicineSearchItem]:
        by_slug: dict[str, MedicineSearchItem] = {}
        self._collect_serper_search_rows(payload, by_slug)
        return list(by_slug.values())[:limit]

    def _split_serper_offers(
        self,
        payload: dict[str, Any],
        city: str,
    ) -> tuple[list[PharmacyOffer], list[PharmacyOffer]]:
        exact: list[PharmacyOffer] = []
        nearby: list[PharmacyOffer] = []
        seen: set[str] = set()
        city_ua = _resolve_city_ua(city)

        for row in payload.get("organic", []):
            link = _serper_row_link(row)
            if not link:
                continue
            row_slug = extract_slug(link)
            if not row_slug or row_slug.lower() in EXCLUDED_SLUGS:
                continue

            title = (row.get("title") or "").strip()
            snippet = row.get("snippet") or ""
            text = f"{title} {snippet}"

            city_match = PHARMACY_PATH_CITY_RE.search(unquote(link))
            if city_match:
                raw_url_city = city_match.group(1)
                if _PLACE_ID_RE.match(raw_url_city or ""):
                    # Google Place IDs are not cities; fall back to text matching.
                    city_match = None
            if city_match:
                raw_url_city = city_match.group(1)
                is_exact = _city_matches(raw_url_city, city, city_ua)
                offer_city = city_ua if is_exact else _format_city_name(raw_url_city)
            else:
                # No city in URL: treat as exact if city name/stem appears in title or snippet.
                t_ua = city_ua.lower()
                stem = t_ua[:-1] if len(t_ua) >= 4 else t_ua
                is_exact = (stem in text.lower()) or (city.lower() in text.lower())
                offer_city = city_ua if is_exact else None

            price = extract_price_from_serper_row(row)
            pharmacy = title.split("|")[0].split("—")[0].split(":")[0].strip() or "Аптека"
            key = f"{pharmacy.lower()}:{offer_city}:{price}:{link}"
            if key in seen:
                continue
            seen.add(key)

            offer = PharmacyOffer(
                pharmacy_name=pharmacy,
                city=offer_city,
                is_nearby=not is_exact,
                address=_extract_address(snippet),
                price_uah=price,
                availability=_extract_availability(text, row.get("attributes")),
                booking_url=link,
            )
            if is_exact:
                exact.append(offer)
            else:
                nearby.append(offer)

        return exact, nearby

    def parse_serper_offers(
        self,
        payload: dict[str, Any],
        slug: str,
        city: str,
        limit: int = 10,
    ) -> list[PharmacyOffer]:
        exact, nearby = self._split_serper_offers(payload, city=city)
        selected = exact if exact else nearby
        return selected[:limit]

    def _is_waf_blocked(self, status_code: int, html: str) -> bool:
        if status_code in (403, 429, 503):
            return True
        lower = html.lower()
        return any(marker.lower() in lower for marker in self.selectors.get("waf_markers", []))

    async def _fetch_playwright(self, url: str) -> str:
        from playwright.async_api import async_playwright

        logger.info("Перемикання на Playwright fallback для %s", url)
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            try:
                context = await browser.new_context(user_agent=settings.user_agent, locale="uk-UA")
                page = await context.new_page()
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                await page.wait_for_timeout(1500)
                return await page.content()
            finally:
                await browser.close()

    async def fetch_html(self, url: str) -> tuple[str, str]:
        await self.limiter.acquire()
        try:
            resp = await self._http.get(url)
            if not self._is_waf_blocked(resp.status_code, resp.text):
                resp.raise_for_status()
                return resp.text, "httpx"
            logger.warning("Отримано WAF/статус %s на %s", resp.status_code, url)
        except httpx.HTTPError as exc:
            logger.warning("Помилка httpx на %s: %s", url, exc)
            if not settings.enable_playwright_fallback:
                if self.serper_api_key:
                    raise
                raise RuntimeError(
                    f"Direct request to {url} failed ({exc}). {SERPER_KEY_MISSING_MSG}"
                ) from exc

        if not settings.enable_playwright_fallback:
            if self.serper_api_key:
                raise RuntimeError(f"Сторінка {url} заблокована WAF, а Playwright fallback вимкнено.")
            raise RuntimeError(
                f"Сторінка {url} заблокована WAF, а Playwright fallback вимкнено. {SERPER_KEY_MISSING_MSG}"
            )

        html = await self._fetch_playwright(url)
        return html, "playwright"

    def parse_search_html(self, html: str, limit: int = 10) -> list[MedicineSearchItem]:
        soup = BeautifulSoup(html, "lxml")
        css = self.selectors["css"]
        items: list[MedicineSearchItem] = []
        seen_slugs: set[str] = set()

        for card in soup.select(css["search_card"]):
            link = card.select_one(css["search_title"])
            if not link or not link.get("href"):
                continue
            href = link["href"]
            slug = extract_slug(href)
            name = link.get_text(" ", strip=True)
            if not name or slug in seen_slugs or slug.lower() in EXCLUDED_SLUGS:
                continue
            seen_slugs.add(slug)

            price_el = card.select_one(css["search_price"])
            price = extract_price(price_el.get_text(" ", strip=True), allow_bare_number=True) if price_el else None
            items.append(
                MedicineSearchItem(
                    name=name,
                    slug=slug,
                    url=urljoin(settings.base_url, href),
                    min_price_uah=price,
                )
            )
            if len(items) >= limit:
                break
        return items

    def parse_offers_html(
        self,
        html: str,
        source_url: str,
        sort_by: str = "price",
        limit: int = 20,
        city: Optional[str] = None,
    ) -> list[PharmacyOffer]:
        soup = BeautifulSoup(html, "lxml")
        css = self.selectors["css"]
        offers: list[PharmacyOffer] = []

        for row in soup.select(css["offer_row"]):
            price_el = row.select_one(css["offer_price"])
            price = extract_price(price_el.get_text(" ", strip=True), allow_bare_number=True) if price_el else None
            name_el = row.select_one(css["pharmacy_name"])
            if not name_el or price is None:
                continue

            addr_el = row.select_one(css["pharmacy_address"])
            avail_el = row.select_one(css["availability"])
            offers.append(
                PharmacyOffer(
                    pharmacy_name=name_el.get_text(" ", strip=True),
                    city=_resolve_city_ua(city) if city else None,
                    is_nearby=False,
                    address=addr_el.get_text(" ", strip=True) if addr_el else None,
                    price_uah=price,
                    availability=avail_el.get_text(" ", strip=True) if avail_el else "Є в наявності",
                    booking_url=source_url,
                )
            )
            if len(offers) >= limit:
                break

        if sort_by == "price":
            offers.sort(key=lambda o: o.price_uah if o.price_uah is not None else float("inf"))
        return offers

    async def search_medicine(self, query: str, limit: int = 10) -> SearchResponse:
        clean_query = query.strip()
        cache_key = f"search:{clean_query.lower()}:{limit}"
        cached = await self.cache.aget(cache_key)
        if cached:
            return SearchResponse(**{**cached, "cached": True})

        if self.serper_api_key:
            by_slug: dict[str, MedicineSearchItem] = {}
            # Primary query: exclude /pharmacy/ and /category/ so all 10 Serper slots go to distinct products.
            payload1 = await self._serper_search(
                f"site:tabletki.ua/uk/ {clean_query} -inurl:pharmacy -inurl:category ціна",
                num=limit,
            )
            self._collect_serper_search_rows(payload1, by_slug)

            # Secondary broad query when few unique products were found (catches canonical /Slug/ and variants).
            if len(by_slug) < min(limit, 5):
                payload2 = await self._serper_search(
                    f"site:tabletki.ua {clean_query} -inurl:pharmacy -inurl:category",
                    num=limit,
                )
                self._collect_serper_search_rows(payload2, by_slug)

            items = list(by_slug.values())[:limit]
        else:
            path = self.selectors["search_path"].format(query=quote(clean_query))
            url = urljoin(settings.base_url, path)
            html, _ = await self.fetch_html(url)
            items = self.parse_search_html(html, limit=limit)

        result = SearchResponse(query=clean_query, count=len(items), cached=False, items=items)
        ttl = settings.cache_ttl_seconds if items else settings.empty_cache_ttl_seconds
        await self.cache.aset(cache_key, result.model_dump(mode="json"), ttl=ttl)
        return result

    async def get_offers(
        self,
        slug: str,
        city: Optional[str] = None,
        sort_by: str = "price",
        limit: int = 10,
    ) -> OffersResponse:
        clean_slug = unquote(slug).strip()
        raw_city = (city or settings.default_city).strip()
        city_slug = raw_city.lower() if raw_city.isascii() else raw_city
        cache_key = f"offers:{clean_slug}:{city_slug}:{sort_by}:{limit}"
        cached = await self.cache.aget(cache_key)
        if cached:
            return OffersResponse(**{**cached, "cached": True})

        path = self.selectors["offers_path"].format(slug=quote(clean_slug), city=quote(city_slug))
        url = urljoin(settings.base_url, path)
        note: Optional[str] = None

        if self.serper_api_key:
            city_ua = _resolve_city_ua(city_slug)
            query_term = _normalize_query_term(clean_slug)
            payload1 = await self._serper_search(
                f'site:tabletki.ua/uk/ {query_term} "{city_ua}" ціна',
                num=limit,
            )
            exact, nearby = self._split_serper_offers(payload1, city=city_slug)

            exact_has_price = any(o.price_uah is not None for o in exact)
            if exact and exact_has_price:
                offers = exact[:limit]
                note = SERPER_OFFERS_NOTE
            else:
                # Fallback: search oblast (if known) or general pharmacies across Ukraine.
                if len(nearby) < min(limit, 3) or (exact and not exact_has_price and not nearby):
                    oblast = _resolve_oblast(city_slug, city_ua)
                    fallback_q = (
                        f"site:tabletki.ua/uk/ {query_term} {oblast} ціна"
                        if oblast
                        else f"site:tabletki.ua/uk/ {query_term} аптеки ціна"
                    )
                    payload2 = await self._serper_search(fallback_q, num=limit)
                    exact2, nearby2 = self._split_serper_offers(payload2, city=city_slug)
                    seen_urls = {o.booking_url for o in nearby}
                    for candidate in exact2 + nearby2:
                        if candidate.booking_url not in seen_urls:
                            candidate.is_nearby = True
                            nearby.append(candidate)
                            seen_urls.add(candidate.booking_url)
                if exact:
                    # Keep exact city rows first, then priced/nearby extras.
                    seen_urls = {o.booking_url for o in exact}
                    combined = list(exact)
                    for candidate in nearby:
                        if candidate.booking_url not in seen_urls:
                            combined.append(candidate)
                            seen_urls.add(candidate.booking_url)
                    offers = combined[:limit]
                    note = SERPER_OFFERS_NOTE if exact_has_price else (
                        SERPER_NEARBY_NOTE if any(o.is_nearby for o in offers) else SERPER_OFFERS_NOTE
                    )
                else:
                    offers = nearby[:limit]
                    note = SERPER_NEARBY_NOTE if offers else SERPER_OFFERS_NOTE
            transport = "serper"
        else:
            html, transport = await self.fetch_html(url)
            offers = self.parse_offers_html(
                html,
                source_url=url,
                sort_by=sort_by,
                limit=limit,
                city=city_slug,
            )

        if sort_by == "price":
            offers.sort(key=lambda o: o.price_uah if o.price_uah is not None else float("inf"))

        prices = [o.price_uah for o in offers if o.price_uah is not None]
        result = OffersResponse(
            slug=clean_slug,
            city=city_slug,
            source_url=url,
            min_price_uah=min(prices) if prices else None,
            max_price_uah=max(prices) if prices else None,
            cached=False,
            transport=transport,
            note=note,
            offers=offers,
        )
        ttl = settings.cache_ttl_seconds if offers else settings.empty_cache_ttl_seconds
        await self.cache.aset(cache_key, result.model_dump(mode="json"), ttl=ttl)
        return result

    async def get_analogues(self, slug: str, limit: int = 15) -> AnaloguesResponse:
        clean_slug = unquote(slug).strip()
        cache_key = f"analogues:{clean_slug}:{limit}"
        cached = await self.cache.aget(cache_key)
        if cached:
            return AnaloguesResponse(**{**cached, "cached": True})

        path = self.selectors["analogues_path"].format(slug=quote(clean_slug))
        url = urljoin(settings.base_url, path)

        if self.serper_api_key:
            query_term = _normalize_query_term(clean_slug)
            by_slug: dict[str, MedicineSearchItem] = {}

            payload1 = await self._serper_search(
                f"site:tabletki.ua/uk/ {query_term} (аналоги OR замінники) -inurl:pharmacy -inurl:category",
                num=limit,
            )
            self._collect_serper_search_rows(payload1, by_slug)
            by_slug.pop(clean_slug.lower(), None)

            if len(by_slug) < min(limit, 4):
                payload2 = await self._serper_search(
                    f"site:tabletki.ua {query_term} аналог ціна -inurl:pharmacy -inurl:category",
                    num=limit,
                )
                self._collect_serper_search_rows(payload2, by_slug)
                by_slug.pop(clean_slug.lower(), None)

            analogues = [
                AnalogueItem(
                    name=item.name,
                    slug=item.slug,
                    url=item.url,
                    min_price_uah=item.min_price_uah,
                )
                for item in list(by_slug.values())[:limit]
            ]
        else:
            html, _ = await self.fetch_html(url)
            soup = BeautifulSoup(html, "lxml")
            css = self.selectors["css"]
            analogues = []
            seen: set[str] = set()
            for link in soup.select(css["analogue_item"]):
                href = link.get("href")
                name = link.get_text(" ", strip=True)
                if not href or not name:
                    continue
                item_slug = extract_slug(href)
                if item_slug in seen or item_slug.lower() == clean_slug.lower():
                    continue
                seen.add(item_slug)
                analogues.append(
                    AnalogueItem(name=name, slug=item_slug, url=urljoin(settings.base_url, href))
                )
                if len(analogues) >= limit:
                    break

        result = AnaloguesResponse(slug=clean_slug, source_url=url, cached=False, analogues=analogues)
        ttl = settings.cache_ttl_seconds if analogues else settings.empty_cache_ttl_seconds
        await self.cache.aset(cache_key, result.model_dump(mode="json"), ttl=ttl)
        return result


_shared_connector: Optional[TabletkiConnector] = None


def get_connector() -> TabletkiConnector:
    """Return a single shared TabletkiConnector instance across FastAPI and MCP."""
    global _shared_connector
    if _shared_connector is None:
        _shared_connector = TabletkiConnector()
    return _shared_connector


async def close_connector() -> None:
    """Close and reset the shared TabletkiConnector instance on shutdown."""
    global _shared_connector
    if _shared_connector is not None:
        await _shared_connector.close()
        _shared_connector = None