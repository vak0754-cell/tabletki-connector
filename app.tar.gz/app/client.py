from __future__ import annotations

import logging
import os
import re
from typing import Any, Optional
from urllib.parse import quote, unquote, urljoin

import httpx
from bs4 import BeautifulSoup

from app.cache import AsyncRateLimiter, SQLiteTTLCache
from app.config import settings
from app.models import (
    AnalogueItem,
    AnaloguesResponse,
    MedicineSearchItem,
    OffersResponse,
    PharmacyOffer,
    SearchResponse,
)

logger = logging.getLogger("tabletki.connector")

# Strip pack counts and dosages (e.g. "№10", "250 мг", "100 мл") before extracting prices.
NON_PRICE_TOKEN_RE = re.compile(
    r"(?:№\s*\d+|\b\d+(?:[.,]\d+)?\s*(?:мг|мкг|мл|г|шт|таб|капс|амп|фл|саше|доз)\b\.?)",
    re.IGNORECASE,
)
# Explicit price with currency symbol/word; supports thousand separators ("1 250.50 грн").
PRICE_RE = re.compile(
    r"(\d{1,3}(?:[\s\xa0]\d{3})+|\d+)(?:[.,](\d{1,2}))?\s*(?:грн|₴|uah)",
    re.IGNORECASE,
)
# Bare number fallback — used ONLY for dedicated HTML price elements, never for raw snippets.
PRICE_BARE_RE = re.compile(
    r"(\d{1,3}(?:[\s\xa0]\d{3})+|\d+)(?:[.,](\d{1,2}))?"
)
PHARMACY_PATH_CITY_RE = re.compile(r"/pharmacy/([^/]+)/?", re.IGNORECASE)

# Free Serper plans reject num > 10 ("Query pattern not allowed for free accounts").
SERPER_MAX_NUM = 10
# Street numbers and pack counts are often parsed as fake prices (e.g. 1 грн).
MIN_PLAUSIBLE_PRICE_UAH = 5.0

SERPER_KEY_MISSING_MSG = (
    "TABLETKI_SERPER_API_KEY is not set. "
    "On Render, add this secret in the service Environment settings. "
    "Without it the connector falls back to direct tabletki.ua requests, which Cloudflare WAF blocks. "
    "Create a key at https://serper.dev and set TABLETKI_SERPER_API_KEY."
)

SERPER_OFFERS_NOTE = (
    "Дані отримано з пошукового індексу Google (Serper), а не з live-залишків аптек. "
    "Перевірте актуальну наявність і ціну за посиланням бронювання."
)

EXCLUDED_SLUGS = frozenset(
    {
        "pharmacy",
        "search",
        "faq",
        "connect",
        "uk",
        "ru",
        "news",
        "articles",
        "about",
        "contacts",
        "category",
        "categories",
        "blog",
        "manufacturer",
        "brand",
        "brands",
    }
)

CITY_UA: dict[str, str] = {
    "kyiv": "Київ",
    "kiev": "Київ",
    "lviv": "Львів",
    "odesa": "Одеса",
    "odessa": "Одеса",
    "dnipro": "Дніпро",
    "kharkiv": "Харків",
    "vinnytsia": "Вінниця",
    "zaporizhzhia": "Запоріжжя",
    "poltava": "Полтава",
    "chernihiv": "Чернігів",
    "cherkasy": "Черкаси",
    "zhytomyr": "Житомир",
    "sumy": "Суми",
    "rivne": "Рівне",
    "lutsk": "Луцьк",
    "ternopil": "Тернопіль",
    "ivano-frankivsk": "Івано-Франківськ",
    "uzhhorod": "Ужгород",
    "chernivtsi": "Чернівці",
    "khmelnytskyi": "Хмельницький",
    "kropyvnytskyi": "Кропивницький",
    "mykolaiv": "Миколаїв",
    "kherson": "Херсон",
    "kryvyi-rih": "Кривий Ріг",
    "bila-tserkva": "Біла Церква",
    "brovary": "Бровари",
    "irpin": "Ірпінь",
    "bucha": "Буча",
    "nizhyn": "Ніжин",
    "pryluky": "Прилуки",
    "nosivka": "Носівка",
    "nosovka": "Носівка",
}


def clamp_serper_num(num: int) -> int:
    """Clamp Serper `num` to 1..10 so free-plan requests are accepted."""
    return max(1, min(int(num), SERPER_MAX_NUM))


def _resolve_serper_key(explicit_key: Optional[str] = None) -> Optional[str]:
    if explicit_key is not None:
        return explicit_key.strip() or None
    env_key = os.getenv("TABLETKI_SERPER_API_KEY")
    if env_key is not None:
        return env_key.strip() or None
    if settings.serper_api_key:
        return settings.serper_api_key.strip() or None
    return None


def missing_serper_key_message() -> Optional[str]:
    if _resolve_serper_key():
        return None
    return SERPER_KEY_MISSING_MSG


def extract_price(text: str, *, allow_bare_number: bool = False) -> Optional[float]:
    """Extract a price in UAH from text.

    For unstructured Google/Serper snippets keep `allow_bare_number=False` so
    dosages ("250 мг"), pack sizes ("№30"), and pharmacy numbers ("Аптека 911")
    are never misread as prices.
    """
    if not text:
        return None
    cleaned = NON_PRICE_TOKEN_RE.sub(" ", text)
    match = PRICE_RE.search(cleaned)
    if not match and allow_bare_number:
        match = PRICE_BARE_RE.search(cleaned)
    if not match:
        return None
    integer_part = re.sub(r"[\s\xa0]+", "", match.group(1))
    decimal_part = match.group(2)
    number_str = f"{integer_part}.{decimal_part}" if decimal_part else integer_part
    try:
        return float(number_str)
    except ValueError:
        return None


def extract_slug(href: str) -> str:
    clean = unquote(href).split("?")[0].split("#")[0]
    for prefix in ("https://tabletki.ua", "http://tabletki.ua", "https://www.tabletki.ua", "http://www.tabletki.ua"):
        if clean.startswith(prefix):
            clean = clean[len(prefix):]
            break
    parts = [p for p in clean.strip("/").split("/") if p]
    if len(parts) >= 2 and parts[0] in ("uk", "ru"):
        return parts[1]
    return parts[0] if parts else clean


def _normalize_query_term(slug: str) -> str:
    return unquote(slug).replace("-", " ").replace("_", " ").strip()


def _city_matches(url_city: str, target_slug: str, target_ua: str) -> bool:
    u = unquote(url_city).strip().lower()
    t_slug = target_slug.strip().lower()
    t_ua = target_ua.strip().lower()
    if u in (t_slug, t_ua):
        return True
    if CITY_UA.get(u, "").lower() == t_ua:
        return True
    # Match Ukrainian inflected stem (e.g. "Носівка" / "Носівки" / "Носівці")
    if len(t_ua) >= 4 and u.startswith(t_ua[:-1]):
        return True
    return False


class TabletkiConnector:
    """Гібридний конектор: Serper Search API (для Render) + прямий httpx/Playwright (локально)."""

    def __init__(self, cache_db_path: Optional[str] = None, serper_api_key: Optional[str] = None) -> None:
        self.selectors = settings.load_selectors()
        self.serper_api_key = _resolve_serper_key(serper_api_key)
        self.cache = SQLiteTTLCache(
            cache_db_path or settings.cache_db_path,
            settings.cache_ttl_seconds,
        )
        self.limiter = AsyncRateLimiter(
            rps=settings.rate_limit_rps,
            min_jitter=settings.min_jitter_sec,
            max_jitter=settings.max_jitter_sec,
        )
        self._http = httpx.AsyncClient(
            http2=True,
            follow_redirects=True,
            timeout=settings.request_timeout_sec,
            headers={
                "User-Agent": settings.user_agent,
                "Accept-Language": "uk-UA,uk;q=0.9,en;q=0.8",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
        )

    async def close(self) -> None:
        await self._http.aclose()

    async def _serper_search(self, query: str, num: int = 10) -> dict[str, Any]:
        if not self.serper_api_key:
            raise RuntimeError(SERPER_KEY_MISSING_MSG)
        await self.limiter.acquire()
        resp = await self._http.post(
            "https://google.serper.dev/search",
            headers={"X-API-KEY": self.serper_api_key, "Content-Type": "application/json"},
            json={"q": query, "gl": "ua", "hl": "uk", "num": clamp_serper_num(num)},
        )
        resp.raise_for_status()
        return resp.json()

    def parse_serper_search(self, payload: dict[str, Any], limit: int = 10) -> list[MedicineSearchItem]:
        items: list[MedicineSearchItem] = []
        seen: set[str] = set()
        for row in payload.get("organic", []):
            link = row.get("link", "")
            if "tabletki.ua" not in link:
                continue
            slug = extract_slug(link)
            if not slug or slug in seen or slug.lower() in EXCLUDED_SLUGS:
                continue
            seen.add(slug)
            title = (row.get("title") or slug).split(":")[0].split("|")[0].strip()
            snippet = f"{row.get('title', '')} {row.get('snippet', '')}"
            price = extract_price(snippet, allow_bare_number=False)
            if price is not None and price < MIN_PLAUSIBLE_PRICE_UAH:
                price = None
            items.append(
                MedicineSearchItem(
                    name=title,
                    slug=slug,
                    url=link if link.startswith("http") else urljoin(settings.base_url, link),
                    min_price_uah=price,
                )
            )
            if len(items) >= limit:
                break
        return items

    def parse_serper_offers(
        self,
        payload: dict[str, Any],
        slug: str,
        city: str,
        limit: int = 10,
    ) -> list[PharmacyOffer]:
        offers: list[PharmacyOffer] = []
        seen: set[str] = set()
        city_lookup = city.lower() if city.isascii() else city
        city_ua = CITY_UA.get(city_lookup, city)

        for row in payload.get("organic", []):
            link = row.get("link") or ""
            if "tabletki.ua" not in link:
                continue
            row_slug = extract_slug(link)
            if not row_slug or row_slug.lower() in EXCLUDED_SLUGS:
                continue

            # If the URL explicitly targets another city's pharmacy page, skip it.
            city_match = PHARMACY_PATH_CITY_RE.search(unquote(link))
            if city_match and not _city_matches(city_match.group(1), city, city_ua):
                continue

            title = (row.get("title") or "").strip()
            snippet = row.get("snippet") or ""
            text = f"{title} {snippet}"

            price = extract_price(text, allow_bare_number=False)
            if price is not None and price < MIN_PLAUSIBLE_PRICE_UAH:
                price = None

            pharmacy = title.split("|")[0].split("—")[0].split(":")[0].strip() or "Аптека"
            key = f"{pharmacy.lower()}:{price}:{link}"
            if key in seen:
                continue
            seen.add(key)
            offers.append(
                PharmacyOffer(
                    pharmacy_name=pharmacy,
                    address=None,
                    price_uah=price,
                    availability="Уточнюйте на сайті",
                    booking_url=link,
                )
            )
            if len(offers) >= limit:
                break
        return offers

    def _is_waf_blocked(self, status_code: int, html: str) -> bool:
        if status_code in (403, 429, 503):
            return True
        lower = html.lower()
        return any(marker.lower() in lower for marker in self.selectors.get("waf_markers", []))

    async def _fetch_playwright(self, url: str) -> str:
        from playwright.async_api import async_playwright

        logger.info("Перемикання на Playwright fallback для %s", url)
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            try:
                context = await browser.new_context(user_agent=settings.user_agent, locale="uk-UA")
                page = await context.new_page()
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                await page.wait_for_timeout(1500)
                return await page.content()
            finally:
                await browser.close()

    async def fetch_html(self, url: str) -> tuple[str, str]:
        await self.limiter.acquire()
        try:
            resp = await self._http.get(url)
            if not self._is_waf_blocked(resp.status_code, resp.text):
                resp.raise_for_status()
                return resp.text, "httpx"
            logger.warning("Отримано WAF/статус %s на %s", resp.status_code, url)
        except httpx.HTTPError as exc:
            logger.warning("Помилка httpx на %s: %s", url, exc)
            if not settings.enable_playwright_fallback:
                if self.serper_api_key:
                    raise
                raise RuntimeError(
                    f"Direct request to {url} failed ({exc}). {SERPER_KEY_MISSING_MSG}"
                ) from exc

        if not settings.enable_playwright_fallback:
            if self.serper_api_key:
                raise RuntimeError(f"Сторінка {url} заблокована WAF, а Playwright fallback вимкнено.")
            raise RuntimeError(
                f"Сторінка {url} заблокована WAF, а Playwright fallback вимкнено. {SERPER_KEY_MISSING_MSG}"
            )

        html = await self._fetch_playwright(url)
        return html, "playwright"

    def parse_search_html(self, html: str, limit: int = 10) -> list[MedicineSearchItem]:
        soup = BeautifulSoup(html, "lxml")
        css = self.selectors["css"]
        items: list[MedicineSearchItem] = []
        seen_slugs: set[str] = set()

        for card in soup.select(css["search_card"]):
            link = card.select_one(css["search_title"])
            if not link or not link.get("href"):
                continue
            href = link["href"]
            slug = extract_slug(href)
            name = link.get_text(" ", strip=True)
            if not name or slug in seen_slugs or slug.lower() in EXCLUDED_SLUGS:
                continue
            seen_slugs.add(slug)

            price_el = card.select_one(css["search_price"])
            price = extract_price(price_el.get_text(" ", strip=True), allow_bare_number=True) if price_el else None
            items.append(
                MedicineSearchItem(
                    name=name,
                    slug=slug,
                    url=urljoin(settings.base_url, href),
                    min_price_uah=price,
                )
            )
            if len(items) >= limit:
                break
        return items

    def parse_offers_html(self, html: str, source_url: str, sort_by: str = "price", limit: int = 20) -> list[PharmacyOffer]:
        soup = BeautifulSoup(html, "lxml")
        css = self.selectors["css"]
        offers: list[PharmacyOffer] = []

        for row in soup.select(css["offer_row"]):
            price_el = row.select_one(css["offer_price"])
            price = extract_price(price_el.get_text(" ", strip=True), allow_bare_number=True) if price_el else None
            name_el = row.select_one(css["pharmacy_name"])
            if not name_el or price is None:
                continue

            addr_el = row.select_one(css["pharmacy_address"])
            avail_el = row.select_one(css["availability"])
            offers.append(
                PharmacyOffer(
                    pharmacy_name=name_el.get_text(" ", strip=True),
                    address=addr_el.get_text(" ", strip=True) if addr_el else None,
                    price_uah=price,
                    availability=avail_el.get_text(" ", strip=True) if avail_el else "Є в наявності",
                    booking_url=source_url,
                )
            )
            if len(offers) >= limit:
                break

        if sort_by == "price":
            offers.sort(key=lambda o: o.price_uah if o.price_uah is not None else float("inf"))
        return offers

    async def search_medicine(self, query: str, limit: int = 10) -> SearchResponse:
        clean_query = query.strip()
        cache_key = f"search:{clean_query.lower()}:{limit}"
        cached = await self.cache.aget(cache_key)
        if cached:
            return SearchResponse(**{**cached, "cached": True})

        if self.serper_api_key:
            payload = await self._serper_search(
                f'site:tabletki.ua/uk/ "{clean_query}" ціна',
                num=limit,
            )
            items = self.parse_serper_search(payload, limit=limit)
        else:
            path = self.selectors["search_path"].format(query=quote(clean_query))
            url = urljoin(settings.base_url, path)
            html, _ = await self.fetch_html(url)
            items = self.parse_search_html(html, limit=limit)

        result = SearchResponse(query=clean_query, count=len(items), cached=False, items=items)
        ttl = settings.cache_ttl_seconds if items else settings.empty_cache_ttl_seconds
        await self.cache.aset(cache_key, result.model_dump(mode="json"), ttl=ttl)
        return result

    async def get_offers(
        self,
        slug: str,
        city: Optional[str] = None,
        sort_by: str = "price",
        limit: int = 10,
    ) -> OffersResponse:
        clean_slug = unquote(slug).strip()
        raw_city = (city or settings.default_city).strip()
        city_slug = raw_city.lower() if raw_city.isascii() else raw_city
        cache_key = f"offers:{clean_slug}:{city_slug}:{sort_by}:{limit}"
        cached = await self.cache.aget(cache_key)
        if cached:
            return OffersResponse(**{**cached, "cached": True})

        path = self.selectors["offers_path"].format(slug=quote(clean_slug), city=quote(city_slug))
        url = urljoin(settings.base_url, path)
        note: Optional[str] = None

        if self.serper_api_key:
            city_lookup = city_slug.lower() if city_slug.isascii() else city_slug
            city_ua = CITY_UA.get(city_lookup, city_slug)
            query_term = _normalize_query_term(clean_slug)
            payload = await self._serper_search(
                f'site:tabletki.ua/uk/ "{query_term}" "{city_ua}" ціна',
                num=limit,
            )
            offers = self.parse_serper_offers(payload, slug=clean_slug, city=city_slug, limit=limit)
            transport = "serper"
            note = SERPER_OFFERS_NOTE
        else:
            html, transport = await self.fetch_html(url)
            offers = self.parse_offers_html(html, source_url=url, sort_by=sort_by, limit=limit)

        if sort_by == "price":
            offers.sort(key=lambda o: o.price_uah if o.price_uah is not None else float("inf"))

        prices = [o.price_uah for o in offers if o.price_uah is not None]
        result = OffersResponse(
            slug=clean_slug,
            city=city_slug,
            source_url=url,
            min_price_uah=min(prices) if prices else None,
            max_price_uah=max(prices) if prices else None,
            cached=False,
            transport=transport,
            note=note,
            offers=offers,
        )
        ttl = settings.cache_ttl_seconds if offers else settings.empty_cache_ttl_seconds
        await self.cache.aset(cache_key, result.model_dump(mode="json"), ttl=ttl)
        return result

    async def get_analogues(self, slug: str, limit: int = 15) -> AnaloguesResponse:
        clean_slug = unquote(slug).strip()
        cache_key = f"analogues:{clean_slug}:{limit}"
        cached = await self.cache.aget(cache_key)
        if cached:
            return AnaloguesResponse(**{**cached, "cached": True})

        path = self.selectors["analogues_path"].format(slug=quote(clean_slug))
        url = urljoin(settings.base_url, path)

        if self.serper_api_key:
            query_term = _normalize_query_term(clean_slug)
            payload = await self._serper_search(
                f'site:tabletki.ua/uk/ "{query_term}" аналоги',
                num=limit,
            )
            analogues = [
                AnalogueItem(
                    name=item.name,
                    slug=item.slug,
                    url=item.url,
                    min_price_uah=item.min_price_uah,
                )
                for item in self.parse_serper_search(payload, limit=limit)
                if item.slug.lower() != clean_slug.lower()
            ]
        else:
            html, _ = await self.fetch_html(url)
            soup = BeautifulSoup(html, "lxml")
            css = self.selectors["css"]
            analogues = []
            seen: set[str] = set()
            for link in soup.select(css["analogue_item"]):
                href = link.get("href")
                name = link.get_text(" ", strip=True)
                if not href or not name:
                    continue
                item_slug = extract_slug(href)
                if item_slug in seen or item_slug.lower() == clean_slug.lower():
                    continue
                seen.add(item_slug)
                analogues.append(
                    AnalogueItem(name=name, slug=item_slug, url=urljoin(settings.base_url, href))
                )
                if len(analogues) >= limit:
                    break

        result = AnaloguesResponse(slug=clean_slug, source_url=url, cached=False, analogues=analogues)
        ttl = settings.cache_ttl_seconds if analogues else settings.empty_cache_ttl_seconds
        await self.cache.aset(cache_key, result.model_dump(mode="json"), ttl=ttl)
        return result


_shared_connector: Optional[TabletkiConnector] = None


def get_connector() -> TabletkiConnector:
    """Return a single shared TabletkiConnector instance across FastAPI and MCP."""
    global _shared_connector
    if _shared_connector is None:
        _shared_connector = TabletkiConnector()
    return _shared_connector


async def close_connector() -> None:
    """Close and reset the shared TabletkiConnector instance on shutdown."""
    global _shared_connector
    if _shared_connector is not None:
        await _shared_connector.close()
        _shared_connector = None