from __future__ import annotations

import logging
import os
import re
from typing import Any, Optional
from urllib.parse import quote, urljoin

import httpx
from bs4 import BeautifulSoup

from app.cache import AsyncRateLimiter, SQLiteTTLCache
from app.config import settings
from app.models import (
    AnalogueItem,
    AnaloguesResponse,
    MedicineSearchItem,
    OffersResponse,
    PharmacyOffer,
    SearchResponse,
)

logger = logging.getLogger("tabletki.connector")
PRICE_RE = re.compile(r"(\d+(?:[.,]\d{1,2})?)\s*(?:грн|₴)", re.IGNORECASE)
PRICE_ANY_RE = re.compile(r"(\d+(?:[.,]\d{1,2})?)")

SERPER_KEY_MISSING_MSG = (
    "TABLETKI_SERPER_API_KEY is not set. "
    "On Render, add this secret in the service Environment settings. "
    "Without it the connector falls back to direct tabletki.ua requests, which Cloudflare WAF blocks. "
    "Create a key at https://serper.dev and set TABLETKI_SERPER_API_KEY."
)

CITY_UA = {
    "kyiv": "Київ",
    "lviv": "Львів",
    "odesa": "Одеса",
    "dnipro": "Дніпро",
    "kharkiv": "Харків",
    "vinnytsia": "Вінниця",
    "nosivka": "Носівка",
    "nosovka": "Носівка",
}


def missing_serper_key_message() -> Optional[str]:
    key = os.getenv("TABLETKI_SERPER_API_KEY")
    if key and key.strip():
        return None
    return SERPER_KEY_MISSING_MSG


def extract_price(text: str) -> Optional[float]:
    if not text:
        return None
    cleaned = text.replace("\xa0", " ").replace(" ", "")
    match = PRICE_RE.search(cleaned) or PRICE_ANY_RE.search(cleaned)
    if not match:
        return None
    try:
        return float(match.group(1).replace(",", "."))
    except ValueError:
        return None


def extract_slug(href: str) -> str:
    clean = href.split("?")[0].split("#")[0]
    for prefix in ("https://tabletki.ua", "http://tabletki.ua"):
        if clean.startswith(prefix):
            clean = clean[len(prefix):]
    parts = [p for p in clean.strip("/").split("/") if p]
    if len(parts) >= 2 and parts[0] == "uk":
        return parts[1]
    return parts[0] if parts else clean


class TabletkiConnector:
    """Гібридний конектор: Serper Search API (для Render) + прямий httpx/Playwright (локально)."""

    def __init__(self, cache_db_path: Optional[str] = None, serper_api_key: Optional[str] = None) -> None:
        self.selectors = settings.load_selectors()
        raw_key = serper_api_key if serper_api_key is not None else os.getenv("TABLETKI_SERPER_API_KEY")
        self.serper_api_key = raw_key.strip() if raw_key and raw_key.strip() else None
        self.cache = SQLiteTTLCache(
            cache_db_path or settings.cache_db_path,
            settings.cache_ttl_seconds,
        )
        self.limiter = AsyncRateLimiter(
            rps=settings.rate_limit_rps,
            min_jitter=settings.min_jitter_sec,
            max_jitter=settings.max_jitter_sec,
        )
        self._http = httpx.AsyncClient(
            http2=True,
            follow_redirects=True,
            timeout=settings.request_timeout_sec,
            headers={
                "User-Agent": settings.user_agent,
                "Accept-Language": "uk-UA,uk;q=0.9,en;q=0.8",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
        )

    async def close(self) -> None:
        await self._http.aclose()

    async def _serper_search(self, query: str, num: int = 10) -> dict[str, Any]:
        if not self.serper_api_key:
            raise RuntimeError(SERPER_KEY_MISSING_MSG)
        resp = await self._http.post(
            "https://google.serper.dev/search",
            headers={"X-API-KEY": self.serper_api_key, "Content-Type": "application/json"},
            json={"q": query, "gl": "ua", "hl": "uk", "num": num},
        )
        resp.raise_for_status()
        return resp.json()

    def parse_serper_search(self, payload: dict[str, Any], limit: int = 10) -> list[MedicineSearchItem]:
        items: list[MedicineSearchItem] = []
        seen: set[str] = set()
        for row in payload.get("organic", []):
            link = row.get("link", "")
            if "tabletki.ua" not in link:
                continue
            slug = extract_slug(link)
            if not slug or slug in seen or slug in ("pharmacy", "search", "faq", "connect", "uk"):
                continue
            seen.add(slug)
            title = (row.get("title") or slug).split(":")[0].split("|")[0].strip()
            snippet = f"{row.get('title', '')} {row.get('snippet', '')}"
            price = extract_price(snippet)
            items.append(
                MedicineSearchItem(
                    name=title,
                    slug=slug,
                    url=link if link.startswith("http") else urljoin(settings.base_url, link),
                    min_price_uah=price,
                )
            )
            if len(items) >= limit:
                break
        return items

    def parse_serper_offers(
        self,
        payload: dict[str, Any],
        slug: str,
        city: str,
        limit: int = 20,
    ) -> list[PharmacyOffer]:
        offers: list[PharmacyOffer] = []
        seen: set[str] = set()
        for row in payload.get("organic", []):
            link = row.get("link") or ""
            if "tabletki.ua" not in link:
                continue
            title = (row.get("title") or "").strip()
            snippet = row.get("snippet") or ""
            text = f"{title} {snippet}"
            if slug.lower() not in extract_slug(link).lower() and slug.lower() not in text.lower():
                # Keep product/pharmacy pages even if the slug is only in the URL path after decode.
                pass
            price = extract_price(text)
            pharmacy = title.split("|")[0].split("—")[0].strip() or "Аптека"
            key = f"{pharmacy}:{price}:{link}"
            if key in seen:
                continue
            seen.add(key)
            offers.append(
                PharmacyOffer(
                    pharmacy_name=pharmacy,
                    address=None,
                    price_uah=price,
                    availability="Уточнюйте на сайті",
                    booking_url=link,
                )
            )
            if len(offers) >= limit:
                break
        return offers

    def _is_waf_blocked(self, status_code: int, html: str) -> bool:
        if status_code in (403, 429, 503):
            return True
        lower = html.lower()
        return any(marker.lower() in lower for marker in self.selectors.get("waf_markers", []))

    async def _fetch_playwright(self, url: str) -> str:
        from playwright.async_api import async_playwright

        logger.info("Перемикання на Playwright fallback для %s", url)
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            context = await browser.new_context(user_agent=settings.user_agent, locale="uk-UA")
            page = await context.new_page()
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(1500)
            html = await page.content()
            await browser.close()
            return html

    async def fetch_html(self, url: str) -> tuple[str, str]:
        await self.limiter.acquire()
        try:
            resp = await self._http.get(url)
            if not self._is_waf_blocked(resp.status_code, resp.text):
                resp.raise_for_status()
                return resp.text, "httpx"
            logger.warning("Отримано WAF/статус %s на %s", resp.status_code, url)
        except httpx.HTTPError as exc:
            logger.warning("Помилка httpx на %s: %s", url, exc)
            if not settings.enable_playwright_fallback:
                if self.serper_api_key:
                    raise
                raise RuntimeError(
                    f"Direct request to {url} failed ({exc}). {SERPER_KEY_MISSING_MSG}"
                ) from exc

        if not settings.enable_playwright_fallback:
            if self.serper_api_key:
                raise RuntimeError(f"Сторінка {url} заблокована WAF, а Playwright fallback вимкнено.")
            raise RuntimeError(
                f"Сторінка {url} заблокована WAF, а Playwright fallback вимкнено. {SERPER_KEY_MISSING_MSG}"
            )

        html = await self._fetch_playwright(url)
        return html, "playwright"

    def parse_search_html(self, html: str, limit: int = 10) -> list[MedicineSearchItem]:
        soup = BeautifulSoup(html, "lxml")
        css = self.selectors["css"]
        items: list[MedicineSearchItem] = []
        seen_slugs: set[str] = set()

        for card in soup.select(css["search_card"]):
            link = card.select_one(css["search_title"])
            if not link or not link.get("href"):
                continue
            href = link["href"]
            slug = extract_slug(href)
            name = link.get_text(" ", strip=True)
            if not name or slug in seen_slugs or slug in ("pharmacy", "search", "faq", "connect"):
                continue
            seen_slugs.add(slug)

            price_el = card.select_one(css["search_price"])
            price = extract_price(price_el.get_text(" ", strip=True)) if price_el else None
            items.append(
                MedicineSearchItem(
                    name=name,
                    slug=slug,
                    url=urljoin(settings.base_url, href),
                    min_price_uah=price,
                )
            )
            if len(items) >= limit:
                break
        return items

    def parse_offers_html(self, html: str, source_url: str, sort_by: str = "price", limit: int = 20) -> list[PharmacyOffer]:
        soup = BeautifulSoup(html, "lxml")
        css = self.selectors["css"]
        offers: list[PharmacyOffer] = []

        for row in soup.select(css["offer_row"]):
            price_el = row.select_one(css["offer_price"])
            price = extract_price(price_el.get_text(" ", strip=True)) if price_el else None
            name_el = row.select_one(css["pharmacy_name"])
            if not name_el or price is None:
                continue

            addr_el = row.select_one(css["pharmacy_address"])
            avail_el = row.select_one(css["availability"])
            offers.append(
                PharmacyOffer(
                    pharmacy_name=name_el.get_text(" ", strip=True),
                    address=addr_el.get_text(" ", strip=True) if addr_el else None,
                    price_uah=price,
                    availability=avail_el.get_text(" ", strip=True) if avail_el else "Є в наявності",
                    booking_url=source_url,
                )
            )
            if len(offers) >= limit:
                break

        if sort_by == "price":
            offers.sort(key=lambda o: o.price_uah if o.price_uah is not None else float("inf"))
        return offers

    async def search_medicine(self, query: str, limit: int = 10) -> SearchResponse:
        cache_key = f"search:{query.strip().lower()}:{limit}"
        cached = self.cache.get(cache_key)
        if cached:
            return SearchResponse(**{**cached, "cached": True})

        if self.serper_api_key:
            payload = await self._serper_search(
                f'site:tabletki.ua/uk/ "{query.strip()}" ціна',
                num=limit,
            )
            items = self.parse_serper_search(payload, limit=limit)
        else:
            path = self.selectors["search_path"].format(query=quote(query.strip()))
            url = urljoin(settings.base_url, path)
            html, _ = await self.fetch_html(url)
            items = self.parse_search_html(html, limit=limit)

        result = SearchResponse(query=query, count=len(items), cached=False, items=items)
        self.cache.set(cache_key, result.model_dump(mode="json"))
        return result

    async def get_offers(
        self,
        slug: str,
        city: Optional[str] = None,
        sort_by: str = "price",
        limit: int = 20,
    ) -> OffersResponse:
        raw_city = (city or settings.default_city).strip()
        # Latin slugs are case-insensitive (kyiv); keep original spelling for Ukrainian names (Носівка).
        city_slug = raw_city.lower() if raw_city.isascii() else raw_city
        cache_key = f"offers:{slug}:{city_slug}:{sort_by}:{limit}"
        cached = self.cache.get(cache_key)
        if cached:
            return OffersResponse(**{**cached, "cached": True})

        path = self.selectors["offers_path"].format(slug=quote(slug), city=quote(city_slug))
        url = urljoin(settings.base_url, path)

        if self.serper_api_key:
            city_lookup = city_slug.lower() if city_slug.isascii() else city_slug
            city_ua = CITY_UA.get(city_lookup, city_slug)
            payload = await self._serper_search(
                f'site:tabletki.ua/uk/ "{slug}" "{city_ua}" ціна',
                num=limit,
            )
            offers = self.parse_serper_offers(payload, slug=slug, city=city_slug, limit=limit)
            transport = "serper"
        else:
            html, transport = await self.fetch_html(url)
            offers = self.parse_offers_html(html, source_url=url, sort_by=sort_by, limit=limit)

        if sort_by == "price":
            offers.sort(key=lambda o: o.price_uah if o.price_uah is not None else float("inf"))

        prices = [o.price_uah for o in offers if o.price_uah is not None]
        result = OffersResponse(
            slug=slug,
            city=city_slug,
            source_url=url,
            min_price_uah=min(prices) if prices else None,
            max_price_uah=max(prices) if prices else None,
            cached=False,
            transport=transport,
            offers=offers,
        )
        self.cache.set(cache_key, result.model_dump(mode="json"))
        return result

    async def get_analogues(self, slug: str, limit: int = 15) -> AnaloguesResponse:
        cache_key = f"analogues:{slug}:{limit}"
        cached = self.cache.get(cache_key)
        if cached:
            return AnaloguesResponse(**{**cached, "cached": True})

        path = self.selectors["analogues_path"].format(slug=quote(slug))
        url = urljoin(settings.base_url, path)

        if self.serper_api_key:
            payload = await self._serper_search(
                f'site:tabletki.ua/uk/ "{slug}" аналоги',
                num=limit,
            )
            analogues = [
                AnalogueItem(
                    name=item.name,
                    slug=item.slug,
                    url=item.url,
                    min_price_uah=item.min_price_uah,
                )
                for item in self.parse_serper_search(payload, limit=limit)
                if item.slug != slug
            ]
        else:
            html, _ = await self.fetch_html(url)
            soup = BeautifulSoup(html, "lxml")
            css = self.selectors["css"]
            analogues = []
            seen: set[str] = set()
            for link in soup.select(css["analogue_item"]):
                href = link.get("href")
                name = link.get_text(" ", strip=True)
                if not href or not name:
                    continue
                item_slug = extract_slug(href)
                if item_slug in seen or item_slug == slug:
                    continue
                seen.add(item_slug)
                analogues.append(
                    AnalogueItem(name=name, slug=item_slug, url=urljoin(settings.base_url, href))
                )
                if len(analogues) >= limit:
                    break

        result = AnaloguesResponse(slug=slug, source_url=url, cached=False, analogues=analogues)
        self.cache.set(cache_key, result.model_dump(mode="json"))
        return result
