from __future__ import annotations

import asyncio
import html
import logging
import secrets
from collections import OrderedDict

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.client import TabletkiConnector
from app.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("tabletki.bot")

MAX_CALLBACK_CACHE = 500


class _SlugTokenStore:
    """Maps short ASCII tokens to (slug, name) so Telegram callback_data stays under 64 bytes."""

    def __init__(self, max_size: int = MAX_CALLBACK_CACHE) -> None:
        self._max_size = max_size
        self._data: OrderedDict[str, tuple[str, str]] = OrderedDict()

    def put(self, slug: str, name: str) -> str:
        token = secrets.token_hex(6)
        self._data[token] = (slug, name)
        self._data.move_to_end(token)
        while len(self._data) > self._max_size:
            self._data.popitem(last=False)
        return token

    def get(self, token: str) -> tuple[str, str] | None:
        return self._data.get(token)


def _fmt_price(price: float | None, prefix: str = "") -> str:
    if price is None:
        return "ціну уточнюйте"
    formatted = f"{price:.2f}".rstrip("0").rstrip(".")
    return f"{prefix}{formatted} грн"


async def run_bot() -> None:
    if not settings.telegram_bot_token:
        raise RuntimeError("Вкажіть TABLETKI_TELEGRAM_BOT_TOKEN у змінних середовища або .env")

    bot = Bot(token=settings.telegram_bot_token)
    dp = Dispatcher()
    connector = TabletkiConnector()
    tokens = _SlugTokenStore()
    user_cities: dict[int, str] = {}

    def get_city(chat_id: int) -> str:
        return user_cities.get(chat_id, settings.default_city)

    @dp.message(CommandStart())
    async def cmd_start(message: Message) -> None:
        city = html.escape(get_city(message.chat.id))
        await message.answer(
            "Привіт! Надішліть назву препарату (наприклад, <b>Нурофєн</b>), "
            f"і я знайду ціни та аналоги в аптеках (поточне місто: <b>{city}</b>).\n\n"
            "Щоб змінити місто, надішліть: <code>/city Львів</code> або <code>/city Носівка</code>.",
            parse_mode="HTML",
        )

    @dp.message(Command("city"))
    async def cmd_city(message: Message) -> None:
        parts = (message.text or "").split(maxsplit=1)
        if len(parts) < 2 or not parts[1].strip():
            current = html.escape(get_city(message.chat.id))
            await message.answer(
                f"Поточне місто: <b>{current}</b>.\n"
                "Вкажіть нове місто після команди, наприклад: <code>/city Носівка</code>",
                parse_mode="HTML",
            )
            return
        new_city = parts[1].strip()
        user_cities[message.chat.id] = new_city
        await message.answer(
            f"Місто для пошуку змінено на: <b>{html.escape(new_city)}</b>",
            parse_mode="HTML",
        )

    @dp.message(F.text)
    async def handle_search(message: Message) -> None:
        query = (message.text or "").strip()
        if query.startswith("/"):
            return
        if len(query) < 2:
            await message.answer("Введіть щонайменше 2 символи для пошуку.")
            return

        wait_msg = await message.answer(f"Шукаю «{html.escape(query)}»...", parse_mode="HTML")
        try:
            res = await connector.search_medicine(query=query, limit=6)
        except Exception as exc:
            logger.exception("Помилка пошуку в боті")
            await wait_msg.edit_text(f"Не вдалося виконати пошук: {exc}")
            return

        if not res.items:
            await wait_msg.edit_text("Нічого не знайдено. Спробуйте іншу назву.")
            return

        buttons: list[list[InlineKeyboardButton]] = []
        for item in res.items:
            token = tokens.put(item.slug, item.name)
            price_label = _fmt_price(item.min_price_uah, prefix="від ")
            buttons.append(
                [
                    InlineKeyboardButton(
                        text=f"{item.name[:38]} ({price_label})",
                        callback_data=f"o:{token}",
                    ),
                    InlineKeyboardButton(
                        text="Аналоги",
                        callback_data=f"a:{token}",
                    ),
                ]
            )
        await wait_msg.edit_text(
            "Оберіть препарат, щоб переглянути ціни або аналоги:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        )

    @dp.callback_query(F.data.startswith("o:"))
    async def handle_offers(callback: CallbackQuery) -> None:
        token = (callback.data or "").split(":", 1)[1]
        entry = tokens.get(token)
        if not entry:
            await callback.answer("Кнопка застаріла — повторіть пошук.", show_alert=True)
            return
        slug, name = entry
        city = get_city(callback.message.chat.id) if callback.message else settings.default_city
        await callback.answer("Завантажую ціни...")

        try:
            data = await connector.get_offers(slug=slug, city=city, limit=8)
        except Exception as exc:
            logger.exception("Помилка завантаження цін у боті")
            if callback.message:
                await callback.message.answer(f"Помилка завантаження цін: {exc}")
            return

        if not callback.message:
            return

        if not data.offers:
            await callback.message.answer(
                f"Пропозицій у місті <b>{html.escape(data.city)}</b> не знайдено.\n"
                f"<a href='{html.escape(data.source_url)}'>Перевірити на Tabletki.ua</a>",
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            return

        header_price = _fmt_price(data.min_price_uah, prefix="від ")
        lines = [
            f"<b>{html.escape(name)}</b> ({html.escape(data.city)}) — <b>{header_price}</b>:",
            "",
        ]
        for offer in data.offers:
            addr = f" — {html.escape(offer.address)}" if offer.address else ""
            pharmacy = html.escape(offer.pharmacy_name)
            lines.append(f"• <b>{_fmt_price(offer.price_uah)}</b> | {pharmacy}{addr}")
        if data.note:
            lines.append(f"\n<i>{html.escape(data.note)}</i>")
        lines.append(f"\n<a href='{html.escape(data.source_url)}'>Відкрити на Tabletki.ua</a>")
        await callback.message.answer("\n".join(lines), parse_mode="HTML", disable_web_page_preview=True)

    @dp.callback_query(F.data.startswith("a:"))
    async def handle_analogues(callback: CallbackQuery) -> None:
        token = (callback.data or "").split(":", 1)[1]
        entry = tokens.get(token)
        if not entry:
            await callback.answer("Кнопка застаріла — повторіть пошук.", show_alert=True)
            return
        slug, name = entry
        await callback.answer("Шукаю аналоги...")

        try:
            data = await connector.get_analogues(slug=slug, limit=10)
        except Exception as exc:
            logger.exception("Помилка пошуку аналогів у боті")
            if callback.message:
                await callback.message.answer(f"Помилка пошуку аналогів: {exc}")
            return

        if not callback.message:
            return

        if not data.analogues:
            await callback.message.answer(
                f"Аналогів для <b>{html.escape(name)}</b> не знайдено.\n"
                f"<a href='{html.escape(data.source_url)}'>Перевірити на Tabletki.ua</a>",
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            return

        lines = [f"<b>Аналоги для {html.escape(name)}</b>:", ""]
        for item in data.analogues:
            price = f" ({_fmt_price(item.min_price_uah, prefix='від ')})" if item.min_price_uah else ""
            lines.append(
                f"• <a href='{html.escape(item.url)}'>{html.escape(item.name)}</a>{price}"
            )
        await callback.message.answer("\n".join(lines), parse_mode="HTML", disable_web_page_preview=True)

    try:
        logger.info("Запуск Telegram-бота...")
        await dp.start_polling(bot)
    finally:
        await connector.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(run_bot())