from __future__ import annotations

import asyncio
import logging
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app.client import TabletkiConnector
from app.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("tabletki.bot")


async def run_bot() -> None:
    if not settings.telegram_bot_token:
        raise RuntimeError("Вкажіть TABLETKI_TELEGRAM_BOT_TOKEN у змінних середовища або .env")

    bot = Bot(token=settings.telegram_bot_token)
    dp = Dispatcher()
    connector = TabletkiConnector()

    @dp.message(CommandStart())
    async def cmd_start(message: Message) -> None:
        await message.answer(
            "Привіт! Надішліть назву препарату (наприклад, <b>Нурофєн</b>), "
            f"і я знайду ціни та наявність в аптеках ({settings.default_city}).",
            parse_mode="HTML",
        )

    @dp.message(F.text)
    async def handle_search(message: Message) -> None:
        query = (message.text or "").strip()
        if len(query) < 2:
            await message.answer("Введіть щонайменше 2 символи для пошуку.")
            return

        wait_msg = await message.answer(f"Шукаю «{query}»...")
        try:
            res = await connector.search_medicine(query=query, limit=6)
        except Exception as exc:
            await wait_msg.edit_text(f"Не вдалося виконати пошук: {exc}")
            return

        if not res.items:
            await wait_msg.edit_text("Нічого не знайдено. Спробуйте іншу назву.")
            return

        buttons = [
            [
                InlineKeyboardButton(
                    text=f"{item.name[:45]} ({f'від {item.min_price_uah} грн' if item.min_price_uah else 'ціна?'})",
                    callback_data=f"offers:{item.slug[:50]}",
                )
            ]
            for item in res.items
        ]
        await wait_msg.edit_text(
            "Оберіть препарат, щоб переглянути ціни в аптеках:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        )

    @dp.callback_query(F.data.startswith("offers:"))
    async def handle_offers(callback: CallbackQuery) -> None:
        slug = callback.data.split(":", 1)[1]
        await callback.answer("Завантажую ціни...")
        try:
            data = await connector.get_offers(slug=slug, city=settings.default_city, limit=8)
        except Exception as exc:
            await callback.message.answer(f"Помилка завантаження цін: {exc}")
            return

        if not data.offers:
            await callback.message.answer(f"Пропозицій не знайдено. Перевірте на сайті: {data.source_url}")
            return

        lines = [f"<b>{slug}</b> ({data.city}) — від <b>{data.min_price_uah} грн</b>:", ""]
        for offer in data.offers:
            addr = f" — {offer.address}" if offer.address else ""
            lines.append(f"• <b>{offer.price_uah} грн</b> | {offer.pharmacy_name}{addr}")
        lines.append(f"\n<a href='{data.source_url}'>Відкрити на Tabletki.ua</a>")
        await callback.message.answer("\n".join(lines), parse_mode="HTML", disable_web_page_preview=True)

    try:
        logger.info("Запуск Telegram-бота...")
        await dp.start_polling(bot)
    finally:
        await connector.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(run_bot())
