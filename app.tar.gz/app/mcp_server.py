from __future__ import annotations

from typing import Annotated

from fastmcp import FastMCP
from pydantic import Field

from app.client import TabletkiConnector

mcp = FastMCP(
    "tabletki-ua-connector",
    instructions=(
        "Search medicines on Tabletki.ua, look up pharmacy prices and stock "
        "by Ukrainian city, and find analogue medicines. "
        "Typical flow: search_medicine to get a slug, then get_medicine_offers "
        "with that slug and a city slug such as kyiv, lviv, or nosivka."
    ),
)
connector = TabletkiConnector()


@mcp.tool()
async def search_medicine(
    query: Annotated[
        str,
        Field(
            description="Medicine name or active ingredient, e.g. Compeed or Dr.DRY.",
            min_length=2,
        ),
    ],
    limit: Annotated[
        int,
        Field(description="Maximum number of results to return (1-30).", ge=1, le=30),
    ] = 10,
) -> dict:
    """Search medicines on Tabletki.ua by name or active ingredient.

    Returns matching products with name, slug, product URL, and starting price in UAH.
    Use the returned slug with get_medicine_offers or get_medicine_analogues.
    """
    res = await connector.search_medicine(query=query, limit=limit)
    return res.model_dump(mode="json")


@mcp.tool()
async def get_medicine_offers(
    slug: Annotated[
        str,
        Field(
            description="Medicine slug from search_medicine results, e.g. Compeed or Dr-Dry.",
            min_length=1,
        ),
    ],
    city: Annotated[
        str,
        Field(
            description=(
                "City name in Latin letters, e.g. kyiv, lviv, nosivka. "
                "Ukrainian names such as Носівка are also accepted."
            ),
            min_length=1,
        ),
    ] = "kyiv",
    limit: Annotated[
        int,
        Field(description="Maximum number of pharmacy offers to return (1-50).", ge=1, le=50),
    ] = 20,
) -> dict:
    """Get pharmacy prices and stock for a medicine in a Ukrainian city.

    Returns pharmacy name, address, price in UAH, availability, and a booking URL.
    """
    res = await connector.get_offers(slug=slug, city=city, limit=limit)
    return res.model_dump(mode="json")


@mcp.tool()
async def get_medicine_analogues(
    slug: Annotated[
        str,
        Field(
            description="Medicine slug from search_medicine results.",
            min_length=1,
        ),
    ],
    limit: Annotated[
        int,
        Field(description="Maximum number of analogues to return (1-30).", ge=1, le=30),
    ] = 15,
) -> dict:
    """Find analogue medicines that share the same active ingredient.

    Returns analogue name, slug, and product URL.
    """
    res = await connector.get_analogues(slug=slug, limit=limit)
    return res.model_dump(mode="json")


if __name__ == "__main__":
    mcp.run()
