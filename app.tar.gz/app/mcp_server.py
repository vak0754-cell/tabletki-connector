from __future__ import annotations

from typing import Annotated, Literal

from fastmcp import FastMCP
from pydantic import Field

from app.client import get_connector, missing_serper_key_message

READ_ONLY_ANNOTATIONS = {
    "readOnlyHint": True,
    "destructiveHint": False,
    "idempotentHint": True,
    "openWorldHint": True,
}

mcp = FastMCP(
    "tabletki-ua-connector",
    instructions=(
        "Search medicines on Tabletki.ua, look up pharmacy prices and stock "
        "by Ukrainian city, and find analogue medicines. "
        "Typical flow: search_medicine to get a slug, then get_medicine_offers "
        "with that slug and a Ukrainian city name (e.g. Київ, Львів, Носівка) "
        "or Latin slug (e.g. kyiv, lviv, nosivka)."
    ),
)


def _tool_error(exc: Exception) -> RuntimeError:
    text = str(exc)
    hint = missing_serper_key_message()
    if hint and hint not in text:
        text = f"{text} {hint}"
    return RuntimeError(text)


@mcp.tool(annotations=READ_ONLY_ANNOTATIONS)
async def search_medicine(
    query: Annotated[
        str,
        Field(
            description="Medicine name or active ingredient, e.g. Нурофєн, Compeed, or Dr.DRY.",
            min_length=2,
        ),
    ],
    limit: Annotated[
        int,
        Field(description="Maximum number of results to return (1-30).", ge=1, le=30),
    ] = 10,
) -> dict:
    """Search medicines on Tabletki.ua by name or active ingredient.

    Returns matching products with name, slug, product URL, and starting price in UAH.
    Use the returned slug with get_medicine_offers or get_medicine_analogues.
    """
    try:
        res = await get_connector().search_medicine(query=query, limit=limit)
    except Exception as exc:
        raise _tool_error(exc) from exc
    return res.model_dump(mode="json")


@mcp.tool(annotations=READ_ONLY_ANNOTATIONS)
async def get_medicine_offers(
    slug: Annotated[
        str,
        Field(
            description="Medicine slug from search_medicine results, e.g. Compeed or Dr-Dry.",
            min_length=1,
        ),
    ],
    city: Annotated[
        str,
        Field(
            description=(
                "Ukrainian city name (preferred, e.g. Київ, Львів, Носівка) "
                "or Latin city slug (e.g. kyiv, lviv, nosivka)."
            ),
            min_length=1,
        ),
    ] = "kyiv",
    sort_by: Annotated[
        Literal["price", "default"],
        Field(description="Sort offers by lowest price ('price') or keep source order ('default')."),
    ] = "price",
    limit: Annotated[
        int,
        Field(description="Maximum number of pharmacy offers to return (1-50).", ge=1, le=50),
    ] = 10,
) -> dict:
    """Get pharmacy prices and stock for a medicine in a Ukrainian city.

    Returns pharmacy name, address, price in UAH, availability, booking URL,
    and a note when results come from the Google/Serper search index.
    """
    try:
        res = await get_connector().get_offers(slug=slug, city=city, sort_by=sort_by, limit=limit)
    except Exception as exc:
        raise _tool_error(exc) from exc
    return res.model_dump(mode="json")


@mcp.tool(annotations=READ_ONLY_ANNOTATIONS)
async def get_medicine_analogues(
    slug: Annotated[
        str,
        Field(
            description="Medicine slug from search_medicine results.",
            min_length=1,
        ),
    ],
    limit: Annotated[
        int,
        Field(description="Maximum number of analogues to return (1-30).", ge=1, le=30),
    ] = 15,
) -> dict:
    """Find analogue medicines that share the same active ingredient.

    Returns analogue name, slug, product URL, and starting price when available.
    """
    try:
        res = await get_connector().get_analogues(slug=slug, limit=limit)
    except Exception as exc:
        raise _tool_error(exc) from exc
    return res.model_dump(mode="json")


if __name__ == "__main__":
    mcp.run()