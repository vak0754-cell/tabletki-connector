from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from app.client import TabletkiConnector, missing_serper_key_message
from app.config import settings
from app.mcp_server import mcp
from app.models import AnaloguesResponse, OffersResponse, SearchResponse

STATIC_DIR = Path(__file__).with_name("static")

def _error_detail(prefix: str, exc: Exception) -> str:
    detail = f"{prefix}: {exc}"
    hint = missing_serper_key_message()
    if hint and hint not in detail:
        detail = f"{detail} {hint}"
    return detail


connector = TabletkiConnector()

# Streamable HTTP MCP for Gemini Custom apps / MCP clients.
# Mounted at /mcp; path="/" so the public URL is exactly /mcp (not /mcp/mcp).
# Stateless + no auth so a remote client can call initialize, tools/list, and tools/call.
mcp_app = mcp.http_app(path="/", transport="http", stateless_http=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    async with mcp_app.lifespan(app):
        yield
    await connector.close()


app = FastAPI(
    title="Tabletki.ua Consumer Connector",
    version="1.0.0",
    description="Connector for searching medicines, prices, pharmacy stock, and analogues (REST + PWA + Telegram + MCP).",
    lifespan=lifespan,
    redirect_slashes=False,
)

class _RewriteMcpPathMiddleware:
    """Map /mcp to /mcp/ so clients that omit the trailing slash still hit the MCP app."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope.get("type") in ("http", "websocket") and scope.get("path") == "/mcp":
            scope = {**scope, "path": "/mcp/"}
        await self.app(scope, receive, send)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Mcp-Session-Id"],
)
app.add_middleware(_RewriteMcpPathMiddleware)


@app.get("/", include_in_schema=False)
async def mobile_ui() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/manifest.json", include_in_schema=False)
async def pwa_manifest() -> FileResponse:
    return FileResponse(STATIC_DIR / "manifest.json", media_type="application/manifest+json")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "default_city": settings.default_city}


@app.get("/api/v1/search", response_model=SearchResponse)
async def search_medicine(
    q: str = Query(..., min_length=2, description="Medicine name or active ingredient"),
    limit: int = Query(10, ge=1, le=30),
) -> SearchResponse:
    try:
        return await connector.search_medicine(query=q, limit=limit)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=_error_detail("Search error", exc)) from exc


@app.get("/api/v1/offers", response_model=OffersResponse)
async def get_offers(
    slug: str = Query(..., min_length=1, description="Medicine slug from search results"),
    city: str = Query(settings.default_city, description="City in Latin letters, e.g. kyiv, lviv, nosivka"),
    sort: str = Query("price", pattern="^(price|default)$"),
    limit: int = Query(10, ge=1, le=50),
) -> OffersResponse:
    try:
        return await connector.get_offers(slug=slug, city=city, sort_by=sort, limit=limit)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=_error_detail("Offers error", exc)) from exc


@app.get("/api/v1/analogues", response_model=AnaloguesResponse)
async def get_analogues(
    slug: str = Query(..., min_length=1, description="Medicine slug"),
    limit: int = Query(15, ge=1, le=30),
) -> AnaloguesResponse:
    try:
        return await connector.get_analogues(slug=slug, limit=limit)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=_error_detail("Analogues error", exc)) from exc


class _NormalizeMountPath:
    """Starlette Mount('/mcp') yields path='' for /mcp; the MCP route is '/'."""

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope.get("type") in ("http", "websocket") and scope.get("path") == "":
            scope = {**scope, "path": "/"}
        await self.app(scope, receive, send)


# Mount last so named API routes stay on the FastAPI app.
# Accept both /mcp and /mcp/ without a POST 307, which breaks some MCP clients.
app.mount("/mcp", _NormalizeMountPath(mcp_app))
