from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from app.client import close_connector, get_connector, missing_serper_key_message
from app.config import settings
from app.mcp_server import mcp
from app.models import AnaloguesResponse, OffersResponse, SearchResponse

logger = logging.getLogger("tabletki.api")
STATIC_DIR = Path(__file__).with_name("static")

# Streamable HTTP MCP for Gemini Custom apps / MCP clients.
# Mounted at /mcp; path="/" so the public URL is exactly /mcp (not /mcp/mcp).
# Stateless + no auth so a remote client can call initialize, tools/list, and tools/call.
mcp_app = mcp.http_app(path="/", transport="http", stateless_http=True)


def _raise_http_error(prefix: str, exc: Exception) -> None:
    logger.exception("%s: %s", prefix, exc)
    hint = missing_serper_key_message()
    suffix = f" {hint}" if hint else ""

    if isinstance(exc, httpx.TimeoutException):
        raise HTTPException(
            status_code=504,
            detail=f"{prefix}: upstream request timed out.{suffix}",
        ) from exc

    if isinstance(exc, httpx.HTTPStatusError):
        upstream_status = exc.response.status_code
        if upstream_status == 429:
            raise HTTPException(
                status_code=429,
                detail=f"{prefix}: upstream rate limit or Serper quota exceeded.",
            ) from exc
        raise HTTPException(
            status_code=502,
            detail=f"{prefix}: upstream returned HTTP {upstream_status}.{suffix}",
        ) from exc

    detail = f"{prefix}: {exc}"
    if hint and hint not in detail:
        detail = f"{detail} {hint}"
    raise HTTPException(status_code=502, detail=detail) from exc


@asynccontextmanager
async def lifespan(app: FastAPI):
    get_connector()
    async with mcp_app.lifespan(app):
        yield
    await close_connector()


app = FastAPI(
    title="Tabletki.ua Consumer Connector",
    version="1.1.0",
    description="Connector for searching medicines, prices, pharmacy stock, and analogues (REST + PWA + Telegram + MCP).",
    lifespan=lifespan,
    redirect_slashes=False,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Mcp-Session-Id"],
)


@app.get("/", include_in_schema=False)
async def mobile_ui() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/manifest.json", include_in_schema=False)
async def pwa_manifest() -> FileResponse:
    return FileResponse(STATIC_DIR / "manifest.json", media_type="application/manifest+json")


@app.get("/icon.svg", include_in_schema=False)
async def pwa_icon() -> FileResponse:
    return FileResponse(STATIC_DIR / "icon.svg", media_type="image/svg+xml")


@app.get("/health")
async def health() -> dict[str, str]:
    connector = get_connector()
    return {
        "status": "ok",
        "default_city": settings.default_city,
        "transport": "serper" if connector.serper_api_key else "direct",
    }


@app.get("/api/v1/search", response_model=SearchResponse)
async def search_medicine(
    q: str = Query(..., min_length=2, description="Medicine name or active ingredient"),
    limit: int = Query(10, ge=1, le=30),
) -> SearchResponse:
    try:
        return await get_connector().search_medicine(query=q, limit=limit)
    except Exception as exc:
        _raise_http_error("Search error", exc)


@app.get("/api/v1/offers", response_model=OffersResponse)
async def get_offers(
    slug: str = Query(..., min_length=1, description="Medicine slug from search results"),
    city: str = Query(settings.default_city, description="City name (Ukrainian or Latin), e.g. Київ, kyiv, nosivka"),
    sort: str = Query("price", pattern="^(price|default)$"),
    limit: int = Query(10, ge=1, le=50),
) -> OffersResponse:
    try:
        return await get_connector().get_offers(slug=slug, city=city, sort_by=sort, limit=limit)
    except Exception as exc:
        _raise_http_error("Offers error", exc)


@app.get("/api/v1/analogues", response_model=AnaloguesResponse)
async def get_analogues(
    slug: str = Query(..., min_length=1, description="Medicine slug"),
    limit: int = Query(15, ge=1, le=30),
) -> AnaloguesResponse:
    try:
        return await get_connector().get_analogues(slug=slug, limit=limit)
    except Exception as exc:
        _raise_http_error("Analogues error", exc)


class _NormalizeMountPath:
    """Starlette Mount('/mcp') yields path='' or '/' for the sub-app; normalize to '/'."""

    def __init__(self, target_app):
        self.target_app = target_app

    async def __call__(self, scope, receive, send):
        if scope.get("type") in ("http", "websocket") and scope.get("path") in ("", "/"):
            scope = {**scope, "path": "/", "raw_path": b"/"}
        await self.target_app(scope, receive, send)


class _McpRootAlias:
    """Rewrite '/mcp' to '/mcp/' internally.

    Starlette 1.x Mount('/mcp') only matches '^/mcp/.*', and FastAPI's
    redirect_slashes=False (needed so MCP POST is not 307'd) would otherwise
    404 the exact path '/mcp'. This rewrite never sends a redirect.
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope.get("type") in ("http", "websocket") and scope.get("path") == "/mcp":
            raw = scope.get("raw_path") or b"/mcp"
            if raw == b"/mcp" or raw.startswith(b"/mcp?"):
                raw = b"/mcp/" + raw[4:]
            else:
                raw = b"/mcp/"
            scope = {**scope, "path": "/mcp/", "raw_path": raw}
        await self.app(scope, receive, send)


# Mount last so named API routes stay on the FastAPI app.
app.mount("/mcp", _NormalizeMountPath(mcp_app))
# Outermost: rewrite /mcp -> /mcp/ before routing, with no HTTP redirect.
app.add_middleware(_McpRootAlias)
