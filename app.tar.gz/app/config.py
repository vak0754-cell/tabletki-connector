from __future__ import annotations

import json
from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TABLETKI_", env_file=".env", extra="ignore")

    base_url: str = "https://tabletki.ua"
    default_city: str = "kyiv"
    cache_ttl_seconds: int = 1200
    cache_db_path: str = "data/cache.sqlite3"
    rate_limit_rps: float = 1.0
    min_jitter_sec: float = 0.25
    max_jitter_sec: float = 0.85
    request_timeout_sec: float = 15.0
    enable_playwright_fallback: bool = False
    telegram_bot_token: Optional[str] = None
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/128.0.0.0 Safari/537.36"
    )
    selectors_path: str = str(Path(__file__).with_name("selectors.json"))

    def load_selectors(self) -> dict:
        with open(self.selectors_path, "r", encoding="utf-8") as fh:
            return json.load(fh)


settings = Settings()
