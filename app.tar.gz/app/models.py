from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional
from pydantic import BaseModel, Field


class MedicineSearchItem(BaseModel):
    name: str
    slug: str
    url: str
    min_price_uah: Optional[float] = None


class SearchResponse(BaseModel):
    query: str
    count: int
    cached: bool = False
    fetched_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    items: list[MedicineSearchItem]


class PharmacyOffer(BaseModel):
    pharmacy_name: str
    address: Optional[str] = None
    price_uah: Optional[float] = None
    availability: str = "Уточнюйте на сайті"
    booking_url: str


class OffersResponse(BaseModel):
    slug: str
    city: str
    source_url: str
    min_price_uah: Optional[float] = None
    max_price_uah: Optional[float] = None
    cached: bool = False
    transport: str = "httpx"
    fetched_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    offers: list[PharmacyOffer]


class AnalogueItem(BaseModel):
    name: str
    slug: str
    url: str
    min_price_uah: Optional[float] = None


class AnaloguesResponse(BaseModel):
    slug: str
    source_url: str
    cached: bool = False
    fetched_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    analogues: list[AnalogueItem]
